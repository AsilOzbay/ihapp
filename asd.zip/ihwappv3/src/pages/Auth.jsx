export default function Auth() {
    return (
      <div className="p-4">
        <h1 className="text-4xl font-bold text-center">Login or Register</h1>
      </div>
    );
  }
      