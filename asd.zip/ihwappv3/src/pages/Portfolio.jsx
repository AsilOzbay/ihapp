export default function Portfolio() {
    return (
      <div className="p-4">
        <h1 className="text-4xl font-bold text-center">My Portfolio</h1>
      </div>
    );
  }
  